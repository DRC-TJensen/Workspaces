module.exports = {
    "action": "put",
    "requesterEmailAddress": "earl@eeg3.net",
    "requesterUsername": "earltest",
    "requesterBundle": "wsb-92tn3b7gx",
    "ws_status": "Requested"
};