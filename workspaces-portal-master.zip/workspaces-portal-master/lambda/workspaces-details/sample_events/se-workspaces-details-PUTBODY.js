module.exports =
{
    "requestContext": {
        "httpMethod": "POST"
    },
    "body": "{\"action\":\"put\",\"requesterEmailAddress\":\"earl@eeg3.net\",\"requesterUsername\":\"earl\",\"ws_status\":\"Requested\"}"
};