module.exports =
{
    "requestContext": {
        "httpMethod": "POST"
    },
    "body": "earl@eeg3.net,earl"
};