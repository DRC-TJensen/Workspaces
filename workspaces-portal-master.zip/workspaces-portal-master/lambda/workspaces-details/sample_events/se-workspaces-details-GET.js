module.exports =
{
    "requestContext": {
        "httpMethod": "POST"
    },
    "body": "{\"action\":\"get\",\"requesterUsername\":\"earl\",\"requesterEmailAddress\":\"earl1@eeg3.net\"}"    
};