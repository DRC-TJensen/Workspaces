module.exports =
{
    "requestContext": {
        "httpMethod": "POST",
        "authorizer": {
            "claims": {
                "email": "earl@eeg3.net"
            }
        }
    },
    "body": "{\"action\":\"create\",\"username\":\"earl\",\"bundle\":\"wsb-92tn3b7gx\"}"
};