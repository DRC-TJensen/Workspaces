module.exports =
{
    "requestContext": {
        "httpMethod": "POST",
        "authorizer": {
            "claims": {
                "email": "earl@eeg3.net"
            }
        }
    },
    "body": "{\"action\":\"acknowledge\",\"username\":\"earltest\"}"
};